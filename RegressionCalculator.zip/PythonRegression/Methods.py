import numpy as np
from scipy.optimize import curve_fit
from sympy import Symbol, diff, integrate
import matplotlib.pyplot as plt
import math
import csv

def linear(time, a, b):
    return a * time + b

def quadratic(time, a, b, c):
    return a*(time**2) + b*time + c

def cubic(time, a, b, c, d):
    return a*(time**3) + b*(time**2) + c*time + d

def quartic(time, a, b, c, d, e):
    return a*(time ** 4) + b * (time ** 3) + c * (time**2) + d*time + e

def exponential(time, a, b):
    return a * (b**time)

def logarithmic(time, a, b):
    return a + (b*np.log(time))

def power(time, a, b):
    return a*(time**b)

def logistic(time, a, b, c):
    return c / (1 + (a * np.exp(-1 * b * time)))

def sinusoidal(time, a, b, c, d):
    return (a * np.sin(b*time + c)) + d

def ninth_degree(time, a, b, c, d, e, f, g, h, i, j):
    return a*(time**9)+ b*(time**8)+c*(time**7)+d*(time**6)+e*(time**5)+f*(time**4)+g*(time**3)+h*(time**2)+i*time+j

def eleventh_degree(time, a, b, c, d, e, f, g, h, i, j, k, l):
    return a * (time ** 11) + b * (time ** 10) + c * (time ** 9) + d * (time ** 8) + e * (time ** 7) + f * (time ** 6) + g * (time ** 5) + h * (time ** 4) + i * (time**3) + j*(time**2)+ k*time + l

"""Purpose: To calculate the standard error, which measures the accuracy of a regression. The lower the standard error, the better"""
def standard_error(fitted_data, position):
    error_list = [(fitted_data[i] - position[i])**2 for i in range(len(position+1))]
    return math.sqrt(sum(error_list)/(len(position)-2))

"""Purpose: To plot all of the original data in one graph, excluding the regression"""
def plot_original(file_data):
    time = file_data[:, 0]
    position = file_data[:, 58]
    plt.plot(time, position, 'r')
    plt.savefig('original')
    plt.show()

def plot_regression(fitted_data, time, position, test_number, row_U, row_L, trial_name):
    #plot data
    plt.ylabel('Position')
    plt.xlabel('Time')
    plt.suptitle('Regression(green) Versus Original(red)')
    plt.gca().set_xlim(xmin=time[0])
    plt.gca().set_xlim(xmax=time[row_U - row_L - 1])

    plt.plot(time, position, 'r')
    plt.plot(time, fitted_data, 'g')
    #plt.plot(time, jerk_fit, 'b')

    #save graph
    plt.savefig(trial_name + str(test_number))

#is not being used
"""Purpose: To save the coefficients of the regression equation into a numpy array"""
def solution_to_array(solution, solution_array):
    #turns solution from list into an array
    solution = np.asarray(solution)
    solution = np.hstack((np.zeros(10 - solution.shape[0]), solution))
    return np.vstack((solution_array, solution))

#currently doesn't work and is not being used
"""Purpose: To save the coefficients into a csv file"""
def save_csv(solution_array, test_number):
    with open('stepupSolutions.csv', mode='w') as file:
        file_writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        for row in range(1, test_number+1):
            solution_list = []
            for col in range(0, 10):
                    solution_list.append(solution_array[row][col])
            print(solution_list)
            file_writer.writerow(solution_list)

"""Purpose: To calculate the normalized jerk of a section of data"""
def normalized_jerk(solution, idx, row_U, row_L, time, position):
    #t represents time
    t = Symbol('t')

    #take the third derivative of position
    jerk = diff(equations(idx)(t, *solution), t, 3)
    print("The jerk equation is" + str(jerk))

    #square the jerk function and multiply by duration^5 / length^2
    jerk_squared = (jerk * jerk) * (((time[row_U - row_L - 1] - time[0]) ** 5) / ((position[row_U - row_L - 1] - position[0]) ** 2))

    #integrate the square of jerk, multiply by 0.5, and then square root it to find normalized jerk
    normal_jerk = math.sqrt((integrate(jerk_squared, (t, time[0], time[row_U - row_L - 1]))) * 0.5)
    print("It has a normalized jerk of " + str(normal_jerk))
    print()

def equation_names(equation):

    #select equation name based on input
    equation_names = {
        0: 'linear',
        1: 'cubic',
        2: 'quartic',
        3: 'sinusoidal',
        4: 'ninth_degree'
    }

    return equation_names[equation]

def number_of_coefficients(equation):
    # selects number of coefficients based on the equation type
    number_of_coefficients = {
        0: 2,
        1: 4,
        2: 5,
        3: 4,
        4: 10
    }

    return number_of_coefficients[equation]

def equations(equation):
    #selects equation based on the input
    equations = {
        0: linear,
        1: cubic,
        2: quartic,
        3: sinusoidal,
        4: ninth_degree
    }

    return equations[equation]

"""Purpose: To perform regression on original data and plot both original and regression data on a graph for comparison"""
def regression(equation, time, position, test_number, row_L, row_U):

    #regression function
    solution, pcov = curve_fit(f=equations(equation), xdata=time, ydata=position, p0=[0.3, ]*number_of_coefficients(equation))

    #turns solution into a list so that it can be graphed
    solution = np.ndarray.tolist(solution)

    #print(str(equation_names[equation]) + " regression has solution" + str(solution))

    #calculates position values based on regression equation
    #saves position values into a list
    fitted_data = [0, ] * len(time)
    for datum in range(0, len(time)):
        fitted_data[datum] = equations(equation)(time[datum], *solution)

    #print("Standard error for "+ str(equation_names[equation]) + str(test_number) + " is " + str(standard_error(fitted_data, position)))

    #returns necessary data
    #standard error is index 0, fitted data is index 1, and solution is index 2
    return standard_error(fitted_data, position), fitted_data, solution






