'''
Author: Teresa Tang
Last updated: 10/01/2018

Purpose: to perform nonlinear regression on data by iterating through different equations (cubic, quadratic, etc) and
comparing

Key:
        0: linear,
        1: cubic,
        2: quartic,
        3: sinusoidal,
        4: ninth_degree

User input required on the following...
        file path name
        trial name
        column index for time
        column index for position
        step

'''

import Methods
import numpy as np
import matplotlib.pyplot as plt

def main():
    #used to save the solutions into a numpy array
    #is not currently being used
    solution_array = np.zeros(10)
    solution_array.astype(float)

    #file names are set below
    sittingClose = "C:\\Users\\Mr. Cuddles\\My Documents\\PythonRegression\\4-30-2017_09-13-AM_Player1_sittingclose.csv"
    stepUP = "C:\\Users\\Mr. Cuddles\\My Documents\\PythonRegression\\StepUP_sequence_Standard_2-1-2013_0146PM_0.csv"
    subject_two = "C:\\Users\\Mr. Cuddles\\My Documents\\PythonRegression\\Subject2_sittingclose_processed.csv"
    subject_two_tstycm = "C:\\Users\\tstycm\\Documents\\PythonRegression\\Subject2_sittingclose_processed.csv"
    subject_four = "C:\\Users\\Mr. Cuddles\\My Documents\\PythonRegression\\Subject4_sittingclose_processed.csv"
    subject_thirtyfour = "C:\\Users\\Mr. Cuddles\\My Documents\\PythonRegression\\Subject34_Sittingclose_processed.csv"
    #change file name and trial name below
    file_data = np.genfromtxt(subject_two_tstycm, delimiter=',')

    #choose what to save the graph names as below
    trial_name = '2subject'

    #Methods.plot_original(file_data)

    #total number of rows in trial data
    num_lines = sum(1 for row in file_data)

    #sections off data
    #step is number of time values per regression
    step = 100
    row_L = 1
    row_U = 0

    #keeps track of which number graph is being created
    test_number = 0


    while row_U < num_lines:

        #if the number of data points remaining is less than step, then the last graph will simply plot all the remaining data points
        #thus, last graph may have less data points than the other graphs
        if (num_lines - row_U) < step:
            row_U = num_lines
        else:
            row_U = row_U + step

        #change column indexes below
        time = file_data[row_L:row_U, 0]
        position = file_data[row_L:row_U, 2]

        #notifies user if there is a error while performing the regression
        solution_list = []
        for equation in range(0, 5):
            try:
                solution_list.append(Methods.regression(equation, time, position, test_number, row_L, row_U)[0])
            except RuntimeError:
                print(str(Methods.equation_names(equation)) + str(test_number) + "failed")

        #finds the minimum standard error and the index at which the minimum standard error is found
        #the index corresponds to the equation type (for example, if index is 1 then the equation must be cubic)
        val, idx = min((val, idx) for (idx, val) in enumerate(solution_list))
        print("Section " + str(test_number) + " has a " + str(Methods.equation_names(idx)) + " solution.")

        #finds the solution that was returned by the regression function
        solution = Methods.regression(idx, time, position, test_number, row_L, row_U)[2]

        #calculate the normalized jerk
        Methods.normalized_jerk(solution, idx, row_U, row_L, time, position)

        #plot the regression on a graph
        fitted_data = Methods.regression(idx, time, position, test_number, row_L, row_U)[1]
        Methods.plot_regression(fitted_data, time, position, test_number, row_U, row_L, trial_name)

        row_L = row_L + step
        test_number = test_number + 1

        #Methods.save_csv(solution_array, test_number)


if __name__ == '__main__':
    main()